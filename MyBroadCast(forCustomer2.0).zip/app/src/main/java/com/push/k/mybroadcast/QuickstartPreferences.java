package com.push.k.mybroadcast;

/**
 * Created by Byron-NB on 2016/4/14.
 */
public class QuickstartPreferences {
    public static final String SENT_TOKEN_TO_SERVER = "sentTokenToServer";
    public static final String REGISTRATION_COMPLETE = "registrationComplete";
}
