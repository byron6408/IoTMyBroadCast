package com.push.k.mybroadcast;


import android.app.Application;
import android.view.View;
import android.widget.TextView;

import com.parse.Parse;
import com.parse.ParseInstallation;
import com.parse.ParsePush;
/**
 * Created by K on 2015/11/18.
 */
public class NotificationList extends Application {

}
